export default function Home(props) {
  return <h1>Home</h1>;
}
