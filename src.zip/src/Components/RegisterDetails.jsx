export default function RgisterDetails(props) {
  return <h1>Register Details</h1>;
}
