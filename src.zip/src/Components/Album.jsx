export default function Album(props){
    return(
        <h1>Albums</h1>
    )
}