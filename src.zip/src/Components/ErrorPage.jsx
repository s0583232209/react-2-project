export default function ErrorPage() {
  return <h1>404 not found</h1>;
}
