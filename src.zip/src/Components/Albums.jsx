export default function Albums(props){
    return <h1>Albums</h1>
}