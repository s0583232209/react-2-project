import { Outlet, Link } from "react-router-dom";
export default function Register(props) {
  return (
    <>
      <h1>Register</h1>
      <Outlet></Outlet>
    </>
  );
}
