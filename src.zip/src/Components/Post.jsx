export default function Post(props){
    return (
        <h1>Post</h1>
    )
}